package com.example.bt_qt_1.DatabaseHelper;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class HistoryDatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "currency_converter.db";
    private static final int DATABASE_VERSION = 1;

    public static final String TABLE_NAME = "history";
    public static final String COLUMN_ID = "id";
    public static final String COLUMN_FROM_CURRENCY = "fromCurrency";
    public static final String COLUMN_TO_CURRENCY = "toCurrency";
    public static final String COLUMN_FROM_MONEY = "fromMoney";
    public static final String COLUMN_TO_MONEY = "toMoney";
    public static final String COLUMN_TIME = "time";

    public HistoryDatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_TABLE = "CREATE TABLE " + TABLE_NAME + " (" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_FROM_CURRENCY + " TEXT, " +
                COLUMN_TO_CURRENCY + " TEXT, " +
                COLUMN_FROM_MONEY + " REAL, " +
                COLUMN_TO_MONEY + " REAL, " +
                COLUMN_TIME + " TEXT)";
        db.execSQL(CREATE_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Xoá bảng nếu đã có và tạo lại
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    public void clearAllHistory() {
        SQLiteDatabase db = this.getWritableDatabase();
        // Xóa tất cả các bản ghi trong bảng history
        db.execSQL("DELETE FROM " + TABLE_NAME);
        db.close();
    }


    // Hàm thêm dữ liệu
    public void insertHistory(String fromCurrency, String toCurrency, String fromMoney, String toMoney, String time) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_FROM_CURRENCY, fromCurrency);
        values.put(COLUMN_TO_CURRENCY, toCurrency);
        values.put(COLUMN_FROM_MONEY, fromMoney);
        values.put(COLUMN_TO_MONEY, toMoney);
        values.put(COLUMN_TIME, time);
        db.insert(TABLE_NAME, null, values);
        db.close();
    }

    // Hàm lấy tất cả history (có thể dùng cho RecyclerView)
    public Cursor getAllHistory() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_NAME + " ORDER BY " + COLUMN_ID + " DESC", null);
    }

    public void deleteHistoryById(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_NAME, COLUMN_ID + "=?", new String[]{String.valueOf(id)});
        db.close();
    }
}
