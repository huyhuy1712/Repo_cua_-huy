package com.example.bt_qt_1;

import android.annotation.SuppressLint;

import android.database.Cursor;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;
import androidx.work.WorkRequest;

import com.example.bt_qt_1.DatabaseHelper.HistoryDatabaseHelper;
import com.example.bt_qt_1.api.ApiService;
import com.example.bt_qt_1.api.CurrencyResponse;
import com.example.bt_qt_1.api.CurrencyUpdateWorker;
import com.example.bt_qt_1.api.UpdateRateReceiver;
import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter;
import com.google.gson.Gson;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {

    private Spinner spinnerCurrency;
    private Spinner spinnerCurrency2;
    private Button exchange_btn;
    private TextView output;
    private EditText input;

    private static final String BASE_URL = "https://v6.exchangerate-api.com/";
    private static final String API_KEY = "56f2fd2f059baa80b0217cd7";

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout);
        spinnerCurrency = findViewById(R.id.spinner_currency);
        spinnerCurrency2 = findViewById(R.id.spinner_currency2);
        exchange_btn = findViewById(R.id.btn_exchange);
        input = findViewById(R.id.input);
        output = findViewById(R.id.output);

        loadCurrencies();
        updateHistoryLayout();

        exchange_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String amountText = input.getText().toString();

                if (amountText.equals("")) {
                    Toast.makeText(getApplicationContext(), "Vui lòng nhập số tiền", Toast.LENGTH_SHORT).show();
                    return;
                }
                else{
                    convertCurrency();
                }
            }
        });

        input.addTextChangedListener(new TextWatcher() {
            private String current = "";

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}

            @Override
            public void afterTextChanged(Editable s) {
                if (!s.toString().equals(current)) {
                    input.removeTextChangedListener(this);

                    String cleanString = s.toString().replace(".", "");
                    try {
                        long parsed = Long.parseLong(cleanString);
                        if (parsed >= 1000) {
                            String formatted = formatNumberWithDots(cleanString);
                            current = formatted;
                            input.setText(formatted);
                            input.setSelection(formatted.length());
                        } else {
                            current = cleanString;
                            input.setText(cleanString);
                            input.setSelection(cleanString.length());
                        }


                    } catch (NumberFormatException e) {
                        e.printStackTrace();
                    }

                    input.addTextChangedListener(this);
                }
            }
        });


        // Đăng ký tác vụ cập nhật tỷ giá hằng ngày
        WorkRequest updateRequest = new PeriodicWorkRequest.Builder(
                CurrencyUpdateWorker.class, 24, TimeUnit.HOURS)
                .build();

        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
                "dailyCurrencyUpdate",
                ExistingPeriodicWorkPolicy.KEEP,
                (PeriodicWorkRequest) updateRequest);

    }

    private void loadCurrencies() {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        ApiService apiService = retrofit.create(ApiService.class);

        Call<CurrencyResponse> call = apiService.getExchangeRates(API_KEY,"VND");

        call.enqueue(new Callback<CurrencyResponse>() {
            @Override
            public void onResponse(Call<CurrencyResponse> call, Response<CurrencyResponse> response) {
                if (response.isSuccessful() && response.body() != null) {
                    CurrencyResponse currencyResponse = response.body();
                    Map<String, Double> currencyMap = currencyResponse.getConversionRates();

                    if (currencyMap != null) {
                        List<String> currencyList = new ArrayList<>(currencyMap.keySet());

                        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                                MainActivity.this,
                                android.R.layout.simple_spinner_item,
                                currencyList
                        );
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        spinnerCurrency.setAdapter(adapter);
                        spinnerCurrency2.setAdapter(adapter);

                    } else {
                        Toast.makeText(MainActivity.this, "Không có conversion_rates", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(MainActivity.this, "Lỗi response", Toast.LENGTH_SHORT).show();
                    Log.e("API_ERR", "Response: " + new Gson().toJson(response.body()));
                }
            }

            @Override
            public void onFailure(Call<CurrencyResponse> call, Throwable t) {
                Toast.makeText(MainActivity.this, "Lỗi: " + t.getMessage(), Toast.LENGTH_SHORT).show();
                Log.e("API_ERR", "Error: ", t);
            }
        });
    }


    // Chuyển đổi tiền tệ
    private void convertCurrency() {
        String fromCurrency = spinnerCurrency.getSelectedItem().toString();
        String toCurrency = spinnerCurrency2.getSelectedItem().toString();
        String amountText = String.valueOf(parseFormattedNumber(input.getText().toString()));
        double amount = Double.parseDouble(amountText);

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        ApiService apiService = retrofit.create(ApiService.class);

        Call<CurrencyResponse> call = apiService.getExchangeRates(API_KEY, fromCurrency);

        call.enqueue(new Callback<CurrencyResponse>() {
            @Override
            public void onResponse(Call<CurrencyResponse> call, Response<CurrencyResponse> response) {
                if (response.isSuccessful() && response.body() != null) {
                    Map<String, Double> conversionRates = response.body().getConversionRates();
                    Double rate = conversionRates.get(toCurrency);

                    Map<String, Double> rates = response.body().getConversionRates();
                    showChart(rates);

                    if (rate != null) {
                        double result = amount * rate;
                        DecimalFormat df = new DecimalFormat("#.#####");
                        output.setText("" + df.format(result));

                        String currentTime = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss", Locale.getDefault()).format(new Date());

                        HistoryDatabaseHelper dbHelper = new HistoryDatabaseHelper(MainActivity.this);

                        dbHelper.insertHistory(spinnerCurrency.getSelectedItem().toString(),spinnerCurrency2.getSelectedItem().toString(),input.getText().toString(),output.getText().toString(),currentTime);
//                        dbHelper.clearAllHistory();
                        updateHistoryLayout();

                    } else {
                        Toast.makeText(MainActivity.this, "Không tìm thấy tỷ giá", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(MainActivity.this, "Lỗi khi nhận dữ liệu", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<CurrencyResponse> call, Throwable t) {
                Toast.makeText(MainActivity.this, "Lỗi kết nối: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    public String formatNumberWithDots(String value) {
        try {
            // Xóa các dấu chấm cũ
            String cleanString = value.replace(".", "");

            long number = Long.parseLong(cleanString);

            DecimalFormatSymbols symbols = new DecimalFormatSymbols();
            symbols.setGroupingSeparator('.');
            DecimalFormat formatter = new DecimalFormat("#,###", symbols);

            return formatter.format(number);
        } catch (NumberFormatException e) {
            return value;
        }
    }

    public long parseFormattedNumber(String value) {
        // Xóa các dấu chấm
        String cleanString = value.replace(".", "");

        try {
            return Long.parseLong(cleanString);
        } catch (NumberFormatException e) {
            e.printStackTrace();
            return 0; // Trả về 0 nếu gặp lỗi
        }
    }

    public void updateHistoryLayout() {
        HistoryDatabaseHelper dbHelper = new HistoryDatabaseHelper(this);
        Cursor cursor = dbHelper.getAllHistory();
        LinearLayout historyContainer = findViewById(R.id.history);
        historyContainer.removeAllViews();

        while (cursor.moveToNext()) {
            int idIndex = cursor.getColumnIndex(HistoryDatabaseHelper.COLUMN_ID);
            int fromCurrencyIndex = cursor.getColumnIndex(HistoryDatabaseHelper.COLUMN_FROM_CURRENCY);
            int toCurrencyIndex = cursor.getColumnIndex(HistoryDatabaseHelper.COLUMN_TO_CURRENCY);
            int fromMoneyIndex = cursor.getColumnIndex(HistoryDatabaseHelper.COLUMN_FROM_MONEY);
            int toMoneyIndex = cursor.getColumnIndex(HistoryDatabaseHelper.COLUMN_TO_MONEY);
            int timeIndex = cursor.getColumnIndex(HistoryDatabaseHelper.COLUMN_TIME);

            if (idIndex != -1 && fromCurrencyIndex != -1 && toCurrencyIndex != -1 &&
                    fromMoneyIndex != -1 && toMoneyIndex != -1 && timeIndex != -1) {

                int id = cursor.getInt(idIndex);
                String fromCurrency = cursor.getString(fromCurrencyIndex);
                String toCurrency = cursor.getString(toCurrencyIndex);
                String fromMoney = cursor.getString(fromMoneyIndex);
                String toMoney = cursor.getString(toMoneyIndex);
                String time = cursor.getString(timeIndex);

                // Tạo layout ngang để chứa nội dung và nút xóa
                LinearLayout itemWrapper = new LinearLayout(this);
                itemWrapper.setOrientation(LinearLayout.HORIZONTAL);
                itemWrapper.setPadding(16, 16, 16, 16);

                // Layout con chứa nội dung (dọc)
                LinearLayout textContainer = new LinearLayout(this);
                textContainer.setOrientation(LinearLayout.VERTICAL);
                textContainer.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));

                TextView resultView = new TextView(this);
                resultView.setText(fromMoney + " " + fromCurrency + " -> " + toMoney + " " + toCurrency);
                resultView.setTextSize(16);
                resultView.setTextColor(Color.BLACK);

                TextView timeView = new TextView(this);
                timeView.setText(time);
                timeView.setTextSize(12);
                timeView.setTextColor(Color.GRAY);

                textContainer.addView(resultView);
                textContainer.addView(timeView);

                Button deleteButton = new Button(this);
                deleteButton.setText("Xóa");
                deleteButton.setTextColor(Color.WHITE);
                deleteButton.setBackgroundColor(Color.parseColor("#FF5252")); // đỏ nhạt
                deleteButton.setPadding(20, 10, 20, 10);

// Bo tròn góc bằng background drawable nếu muốn đẹp hơn
                GradientDrawable shape = new GradientDrawable();
                shape.setCornerRadius(30);
                shape.setColor(Color.parseColor("#FF5252"));
                deleteButton.setBackground(shape);

// Xử lý sự kiện click
                deleteButton.setOnClickListener(v -> {
                    dbHelper.deleteHistoryById(id);
                    updateHistoryLayout();
                });


                // Gộp lại
                itemWrapper.addView(textContainer);
                itemWrapper.addView(deleteButton);
                historyContainer.addView(itemWrapper);
            }
        }

        cursor.close();
    }

    private void showChart(Map<String, Double> rates) {
        LineChart chart = findViewById(R.id.lineChart);

        List<Entry> entries = new ArrayList<>();
        List<String> labels = new ArrayList<>();
        int i = 0;
        for (Map.Entry<String, Double> entry : rates.entrySet()) {
            entries.add(new Entry(i, entry.getValue().floatValue()));
            labels.add(entry.getKey()); // giả sử key là ngày như "17-04"
            i++;
        }

        LineDataSet dataSet = new LineDataSet(entries, "Tỷ giá theo ngày");
        dataSet.setColor(Color.BLUE);
        dataSet.setValueTextColor(Color.BLACK);
        dataSet.setCircleColor(Color.CYAN);
        dataSet.setLineWidth(1f);
        dataSet.setCircleRadius(3f);
        dataSet.setDrawValues(false);

        LineData lineData = new LineData(dataSet);
        chart.setData(lineData);

        // Hiển thị trục X theo label
        XAxis xAxis = chart.getXAxis();
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setGranularity(1f);
        xAxis.setValueFormatter(new IndexAxisValueFormatter(labels));

        chart.getDescription().setText("Ngày");
        chart.invalidate(); // refresh
    }




}
