package com.example.bt_qt_1.api;

import java.util.concurrent.Executor;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;

public interface ApiService {

    @GET("v6/{apiKey}/latest/{baseCurrency}")
    Call<CurrencyResponse> getExchangeRates(
            @Path("apiKey") String apiKey,
            @Path("baseCurrency") String baseCurrency
    );

}


