package com.example.bt_qt_1.api;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CurrencyUpdateWorker extends Worker {

    public CurrencyUpdateWorker(@NonNull Context context, @NonNull WorkerParameters params) {
        super(context, params);
    }

    @NonNull
    @Override
    public Result doWork() {
        ApiService apiService = ApiClient.getClient().create(ApiService.class);
        Call<CurrencyResponse> call = apiService.getExchangeRates("56f2fd2f059baa80b0217cd7", "VND");

        call.enqueue(new Callback<CurrencyResponse>() {
            @Override
            public void onResponse(Call<CurrencyResponse> call, Response<CurrencyResponse> response) {
                if (response.isSuccessful() && response.body() != null) {
                    Map<String, Double> rates = response.body().getConversionRates();
                    // TODO: Lưu rates vào SharedPreferences hoặc Room DB
                }
            }

            @Override
            public void onFailure(Call<CurrencyResponse> call, Throwable t) {
                // Log lỗi nếu cần
            }
        });

        return Result.success(); // Worker báo hoàn thành
    }
}
